// Agha Hussain Ali 
// 0123 

#include <iostream>
using namespace std;

int main()
{
    char grade;
    double gradePoint;

    cout << "Enter grade: ";
    cin >> grade;

    switch (grade)
    {
    case 'A':
    case 'a':

        cout << "Excellent work";
        gradePoint = 4.0;
        break;

    case 'B':
    case 'b':

        cout << "Good";
        gradePoint = 3.0;
        break;

    case 'C':
    case 'c':

        cout << "Satisfactory";
        gradePoint = 2.0;
        break;

    case 'D':
    case 'd':

        cout << "Needs improvement bro ";
        gradePoint = 1.0;
        break;

    case 'F':
    case 'f':
        cout << "Fail";
        gradePoint = 0.0;
        break;

    default:
        cout << "Invalid grade";
        gradePoint = 0.0;
    }

    cout << "\nGrade Point: " << gradePoint;

    return 0;
}