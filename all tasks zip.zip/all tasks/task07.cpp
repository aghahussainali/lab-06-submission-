
#include <iostream>
using namespace std;

int main()
{
    int testScore, matricMarks, interMarks;

    cout << "Enter test score: ";
    cin >> testScore;

    cout << "Enter matric marks: ";
    cin >> matricMarks;

    cout << "Enter intermediate marks: ";
    cin >> interMarks;

    if (testScore >= 50)
    {
        if (matricMarks >= 660)
        {
            if (interMarks >= 660)
            {
                cout << "Admission granted";

                if (testScore >= 90)
                {
                    cout << "\nScholarship: 50%";
                }
                else
                {
                    if (testScore >= 75)
                    {
                        cout << "\nScholarship: 25%";
                    }
                    else
                    {
                        cout << "\nScholarship: None";
                    }
                }
            }
            else
            {
                cout << "Rejected: intermediate marks are below 660";
            }
        }
        else
        {
            cout << "Rejected: matric marks are below 660";
        }
    }
    else
    {
        cout << "Rejected: entry test score is below 50";
    }

    return 0;
}