
#include <iostream>
using namespace std;

int main()
{
    int month;

    cout << "Enter month number (1-12): ";
    cin >> month;

    switch (month)
    {
    case 12:
    case 1:
    case 2:
        cout << "Season: Winter";
        break;

    case 3:
    case 4:
    case 5:
        cout << "Season: Spring";
        break;

    case 6:
    case 7:
    case 8:
        cout << "Season: Summer";
        break;

    case 9:
    case 10:
    case 11:
        cout << "Season: Autumn";
        break;

    default:
        cout << "Invalid month";
    }

    switch (month)
    {
    case 1: case 3: case 5: case 7:
    case 8: case 10: case 12:
        cout << "\nDays: 31";
        break;

    case 4: case 6: case 9: case 11:
        cout << "\nDays: 30";
        break;

    case 2:
        cout << "\nDays: 28";
        break;

    default:
        cout << "\nInvalid month";
    }

    return 0;
}