

#include <iostream>
using namespace std;

int main()
{
    int sideA, sideB, sideC;

    cout << "Enter side A: ";
    cin >> sideA;

    cout << "Enter side B: ";
    cin >> sideB;

    cout << "Enter side C: ";
    cin >> sideC;

    if (sideA > 0)
    {
        if (sideB > 0)
        {
            if (sideC > 0)
            {
                if (sideA + sideB > sideC)
                {
                    if (sideA + sideC > sideB)
                    {
                        if (sideB + sideC > sideA)
                        {
                            cout << "Valid triangle";

                            if (sideA == sideB)
                            {
                                if (sideB == sideC)
                                {
                                    cout << "\nType: Equilateral";
                                }
                                else
                                {
                                    cout << "\nType: Isosceles";
                                }
                            }
                            else
                            {
                                if (sideA == sideC)
                                {
                                    cout << "\nType: Isosceles";
                                }
                                else
                                {
                                    if (sideB == sideC)
                                    {
                                        cout << "\nType: Isosceles";
                                    }
                                    else
                                    {
                                        cout << "\nType: Scalene";
                                    }
                                }
                            }
                        }
                        else
                        {
                            cout << "Not a valid triangle: two sides must add up to more than the third";
                        }
                    }
                    else
                    {
                        cout << "Not a valid triangle: two sides must add up to more than the third";
                    }
                }
                else
                {
                    cout << "Not a valid triangle: two sides must add up to more than the third";
                }
            }
            else
            {
                cout << "Invalid: every side must be greater than 0";
            }
        }
        else
        {
            cout << "Invalid: every side must be greater than 0";
        }
    }
    else
    {
        cout << "Invalid: every side must be greater than 0";
    }

    return 0;
}