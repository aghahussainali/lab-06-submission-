
#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
    char seatType;
    int age, tickets, discountPercent;
    double price, totalCost, ageDiscount, groupOffer, amountPayable;

    cout << "Enter seat type (S/G/P): ";
    cin >> seatType;

    cout << "Enter age: ";
    cin >> age;

    cout << "Enter number of tickets: ";
    cin >> tickets;

    switch (seatType)
    {
    case 'S':
    case 's':
        cout << "Seat type: Standard\n";
        price = 500;
        break;

    case 'G':
    case 'g':
        cout << "Seat type: Gold\n";
        price = 800;
        break;

    case 'P':
    case 'p':
        cout << "Seat type: Platinum\n";
        price = 1200;
        break;

    default:
        cout << "Seat type: Invalid seat type\n";
        price = 0;
    }

    if (age < 5)
    {
        discountPercent = 100;
    }
    else
    {
        if (age < 12)
        {
            discountPercent = 50;
        }
        else
        {
            if (age >= 60)
            {
                discountPercent = 30;
            }
            else
            {
                discountPercent = 0;
            }
        }
    }

    totalCost = price * tickets;
    ageDiscount = totalCost * discountPercent / 100;

    if (tickets >= 5)
    {
        if (totalCost - ageDiscount >= 3000)
        {
            groupOffer = (totalCost - ageDiscount) * 10 / 100;
        }
        else
        {
            groupOffer = 0;
        }
    }
    else
    {
        groupOffer = 0;
    }

    amountPayable = totalCost - ageDiscount - groupOffer;

    cout << fixed << setprecision(2);

    cout << "Ticket price: Rs. " << price;
    cout << "\nTotal cost: Rs. " << totalCost;
    cout << "\nAge discount (" << discountPercent << "%): Rs. " << ageDiscount;
    cout << "\nGroup offer: Rs. " << groupOffer;
    cout << "\nAmount payable: Rs. " << amountPayable;

    return 0;
}