
#include <iostream>
using namespace std;

int main()
{
    int year;

    cout << "Enter a year: ";
    cin >> year;

    if (year > 0)
    {
        if (year % 4 == 0)
        {
            if (year % 100 == 0)
            {
                if (year % 400 == 0)
                {
                    cout << year << " is a leap year";
                    cout << "\nFebruary has 29 days";
                }
                else
                {
                    cout << year << " is not a leap year";
                    cout << "\nFebruary has 28 days";
                }
            }
            else
            {
                cout << year << " is a leap year";
                cout << "\nFebruary has 29 days";
            }
        }
        else
        {
            cout << year << " is not a leap year";
            cout << "\nFebruary has 28 days";
        }
    }
    else
    {
        cout << "Invalid year";
    }

    return 0;
}