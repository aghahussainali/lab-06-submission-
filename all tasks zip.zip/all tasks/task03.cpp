
#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    int choice;
    float value, converted;

    cout << "Unit Converter\n";
    cout << "1. Kilometres to miles\n";
    cout << "2. Kilograms to pounds\n";
    cout << "3. Celsius to Fahrenheit\n";
    cout << "4. Inches to centimetres\n";

    cout << "Enter your choice (1-4): ";
    cin >> choice;

    cout << "Enter the value: ";
    cin >> value;

    switch (choice)
    {
    case 1:
        converted = value * 0.621371;
        cout << fixed << setprecision(2);
        cout << converted << " miles";
        break;

    case 2:



        converted = value * 2.20462;
        cout << fixed << setprecision(2);
        cout << converted << " pounds";
        break;

    case 3:


        converted = value * 9 / 5 + 32;
        cout << fixed << setprecision(2);
        cout << value << " C = " << converted << " F";
        break;

    case 4:

        converted = value * 2.54;
        cout << fixed << setprecision(2);
        cout << converted << " centimetres";
        break;

    default:
        cout << "Invalid choice";
    }

    return 0;
}